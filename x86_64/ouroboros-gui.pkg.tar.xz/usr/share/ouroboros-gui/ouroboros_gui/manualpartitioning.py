filesystems = [
    "don't format",
    "bfs",
    "cramfs",
    "ext3",
    "fat",
    "msdos",
    "xfs",
    "btrfs",
    "ext2",
    "ext4",
    "minix",
    "vfat",
    "f2fs",
]

mountpoints = [
    "none",
    "/",
    "/boot",
    "/boot/efi",
    "/home",
    "/opt",
    "/tmp",
    "/usr",
    "/var",
]
