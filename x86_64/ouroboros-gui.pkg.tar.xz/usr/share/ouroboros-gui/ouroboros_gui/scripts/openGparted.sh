#!/usr/bin/bash
flatpak-spawn --host pkexec gparted