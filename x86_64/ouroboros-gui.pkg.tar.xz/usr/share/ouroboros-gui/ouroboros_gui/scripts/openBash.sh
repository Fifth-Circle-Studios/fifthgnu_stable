#!/usr/bin/bash
flatpak-spawn --host gnome-terminal -- bash