#!/usr/bin/bash
flatpak-spawn --host gnome-session-quit --reboot