from ouroboros_gui.classes.locale import locale

arctic = [
    locale(
        region="Arctic",
        location="Longyearbyen",
        locales="no_NO.UTF-8 UTF-8",
    )
]
