desktops = [
    "Onyx",
    "GNOME",
    "Plasma",
    "XFCE",
    "Sway",
    "i3",
]
