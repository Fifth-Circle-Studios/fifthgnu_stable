#!/usr/bin/bash
flatpak-spawn --host echo $1 > /tmp/jade.json