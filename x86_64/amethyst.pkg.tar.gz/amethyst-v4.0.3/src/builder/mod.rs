pub mod git;
pub mod makepkg;
pub mod paccache;
pub mod pacdiff;
pub mod pacman;
pub mod pager;
pub mod rm;
